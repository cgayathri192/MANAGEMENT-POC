import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators } from '@angular/forms';
import { ManagementService } from '../management.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
registerForm:any;
types = ["savings","Personal",];
names = ["AxisBank","CanaraBank","State Bank of India","ICICI Bank",];
  constructor(private fb:FormBuilder,private ser:ManagementService,private router:Router) { }

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      name:['',[Validators.required]],
      email:['',[Validators.required]],
      bank:['',[Validators.required]],
      account:['',[Validators.required]],
      code:['',[Validators.required]],
      branch:['',[Validators.required]],
      type:['',[Validators.required]],
      number:['',[Validators.required]],
      password:['',[Validators.required]],
      confirm:['',[Validators.required]],
    })

  }
  get registerFormErrors(){
    return this.registerForm.controls
  }
  register(){
    // console.log(this.registerForm.value)
    // console.log(this.registerFormErrors.controls)
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    })

    Toast.fire({
      icon: 'success',
      title: 'Registered successfully!'
    })
    this.ser.postRegister(this.registerForm.value).subscribe((x:any)=>{
      console.log("............................",x)
      sessionStorage.setItem('name', x.name);
      sessionStorage.setItem('password', x.password);
      sessionStorage.setItem('email',x.email);
      sessionStorage.setItem('account',x.account);
      sessionStorage.setItem('bank',x.bank);
      sessionStorage.setItem('code',x.code);
      sessionStorage.setItem('branch',x.branch);
      sessionStorage.setItem('type',x.type);
      sessionStorage.setItem('number',x.number);
      sessionStorage.setItem('confirm',x.confirm);
      if(x.password==x.retypepassword){
      
        this.router.navigateByUrl('login')
       
      }
    })
  
  }
  

}
