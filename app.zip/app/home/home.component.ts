import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ManagementService } from '../management.service';
import { NgxQrcodeElementTypes, NgxQrcodeErrorCorrectionLevels } from '@techiediaries/ngx-qrcode';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
depositForm:any;
withdrawForm:any;
balanceForm:any;
transferForm:any;
pinForm:any;
totalAmount = '';
message = "Entered pin is wrong";
depositPin=sessionStorage.getItem('pin');
depositamount:any = sessionStorage.getItem('deposit')
withdrawamount:any = sessionStorage.getItem('withdraw')
transferamount:any = sessionStorage.getItem('transfer')
generatePin:any = sessionStorage.getItem('pin')
balanceAmount=0;
  constructor(private service:ManagementService) { }

  ngOnInit(): void {
    this.depositForm = new FormGroup({
      accountNumber: new FormControl('', [Validators.required]),
      amount: new FormControl('',[Validators.required]),
      pin: new FormControl('',[Validators.required])
    })
    this.withdrawForm = new FormGroup({
      accountNumber : new FormControl('',[Validators.required]),
      amount:new FormControl('',[Validators.required]),
      pin: new FormControl('',[ Validators.required])
    })
    this.balanceForm = new FormGroup({
      pin: new FormControl('')
    })
    this.transferForm = new FormGroup({
      name: new FormControl('',[Validators.minLength(10),Validators.required]),
      accountNumber: new FormControl('',[Validators.required]),
      amount: new FormControl('',[Validators.required]),
      pin: new FormControl('',[Validators.required])
    })
    this.pinForm = new FormGroup({
     pin: new FormControl('',[Validators.required]),
     rePin: new FormControl('',[Validators.required])
    })

  
   
  
  }
  deposit(){
    // Swal.fire({
    //   title: 'Do you want to save the changes?',
    //   showDenyButton: true,
    //   showCancelButton: true,
    //   confirmButtonText: 'Save',
    //   denyButtonText: `Don't save`,
    // }).then((result) => {
    //   /* Read more about isConfirmed, isDenied below */
    //   if (result.isConfirmed) {
    //     Swal.fire('Saved!', '', 'success')
    //   } else if (result.isDenied) {
    //     Swal.fire('Changes are not saved', '', 'info')
    //   }
    // })
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 1000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: 'success',
      title: 'Money deposited  successfully!',
    });
    this.service.postDeposit(this.depositForm.value).subscribe((x:any)=>{
      sessionStorage.setItem('deposit',x.amount)
      console.log(x)
      if(x.pin === this.generatePin){
        console.log(x,"deposit")
      }
    })
    // Swal.fire({
    //   text:'Are You sure want to Deposit?',
    //   icon:'info',
    //   showCancelButton:true,
    //   confirmButtonText:'Yes',
    //   cancelButtonText:'No'
    // }).then((response:any)=>{
    //   if(response.value){
    //     Swal.fire({
    //       text:'Deposited',
    //       icon:'success'
    //     })
    //   }else if(response.dismiss === Swal.DismissReason.cancel){
    //     Swal.fire({
    //       text:'Not Deposited',
    //       icon:'error'
    //     })
    //   }
    // })
   
  }
  withdraw(){
    this.service.postwithdraw(this.withdrawForm.value).subscribe((x:any)=>{
      console.log(x)
      sessionStorage.setItem('withdraw',x.amount)
      if(x.pin === this.generatePin){
        console.log(x,"withdraw")
      }
    })
    // Swal.fire({
    //   text:'Are you sure want to Withdraw?',
    //   icon:'info',
    //   showCancelButton:true,
    //   confirmButtonText:'Yes',
    //   cancelButtonText:'No'
    // }).then((response:any)=>{
    //   if(response.value){
    //     Swal.fire({
    //       text:'withdrawn',
    //       icon:'success'
    //     })
    //   } else if(response.dismiss === Swal.DismissReason.cancel){
    //     Swal.fire({
    //       text:'Not drawn',
    //       icon:'error'
    //     })
    //   }
    // })
  }
  checkBalance(){
    this.service.postBalance(this.balanceForm.value).subscribe((x:any)=>{
      console.log('balancepin',x)
      console.log(this.depositPin)
      if(x.pin===this.depositPin){
        this.balanceAmount = this.depositamount-this.withdrawamount-this.transferamount;
        console.log(this.balanceAmount,'xxxxxxxxxxxxx')
      }
      else{
        this.message
      }
      if(x.pin === this.generatePin){
        console.log(x,"balance")
      }
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 1000,
        timerProgressBar: true,
        didOpen: (toast: any) => {
          toast.addEventListener('mouseenter', Swal.stopTimer);
          toast.addEventListener('mouseleave', Swal.resumeTimer);
        },
      });
  
      Toast.fire({
        icon: 'success',
        title: 'Balance fetched  successfully!',
      });
    })
  
    
  }
  transfer(){
    this.service.postTransfer(this.transferForm.value).subscribe((x:any)=>{
      sessionStorage.setItem('transfer',x.amount)
      if(x.pin === this.generatePin){
        console.log(x,"transfer")
      }
    })
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 1000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: 'success',
      title: 'Money Transfered Succufully !',
    });
    // Swal.fire({
    //   text:'Are you sure want to Transfer?',
    //   icon:'info',
    //   showCancelButton:true,
    //   confirmButtonText:'Yes',
    //   cancelButtonText:'No'
    // }).then((response: any)=>{
    //   if(response.value){
    //     Swal.fire({
    //       text:'Transfered',
    //       icon:'success'
    //     })
    //   } else if(response.dismiss === Swal.DismissReason.cancel){
    //     Swal.fire({
    //       text:'Not Transfered',
    //       icon:'warning'
    //     })
    //   }
    // })
  }
  pin(){
    this.service.postPin(this.pinForm.value).subscribe((x:any)=>{
      console.log(x,"pin")
    
      if(x.pin == x.rePin){
        sessionStorage.setItem('pin',x.pin)
      }
    })
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 1000,
      timerProgressBar: true,
      didOpen: (toast: any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: 'success',
      title: 'Pin generated  successfully!',
    });
    // Swal.fire({
    //   title: 'Are you sure want to generate?',
    //   icon: 'info',
    //   showCancelButton: true,
    //   confirmButtonText: 'Yes',
    //   cancelButtonText: 'No'
    // }).then((response: any) => {
    //   if (response.value) {
    //     Swal.fire({
    //        text:'Pin Generated',
    //        icon:'success' 
    //     })     
    //    } else if (response.dismiss === Swal.DismissReason.cancel) {
    //     Swal.fire({
    //       text:'Incorrect Pin',
    //       icon:'error'
    //    })
    //   }
    // })
  }
 get depositFormErrors(){
  return this.depositForm.controls
 }
 get withdrawFormErrors(){
  return this.withdrawForm.controls
 }
 get transferFormErrors(){
  return this.transferForm.controls
 }
 get pinFormErrors(){
  return this.pinForm.controls
 }
  }


