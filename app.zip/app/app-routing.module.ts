import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { LoginGuard } from './login.guard';
import { MainComponent } from './main/main.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { TermsComponent } from './terms/terms.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { ScannerComponent } from './scanner/scanner.component';






const routes: Routes = [
  {
    path:'register',
    component:RegisterComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'home',
    component:HomeComponent,
    canActivate:[LoginGuard]
  },
  {
    path:'sidebar',
    component:SidebarComponent
  },
  {
     path:'scanner',
     component:ScannerComponent,
     canActivate:[LoginGuard]
  },
  {
    path:'terms',
    component:TermsComponent,
    canActivate:[LoginGuard]
  },
  {
    path:'userdetails',
    component:UserdetailsComponent,
    canActivate:[LoginGuard]
  },
  {
    path:'main',
    component:MainComponent,
    children:[
      {
        path:'',
        component:HomeComponent
      },
      {
        path:'terms',
        component:TermsComponent
      },
      {
        path:'home',
        component:HomeComponent
      },
      {
        path:'login',
        component:LoginComponent
      },
      {
        path:'userdetails',
        component:UserdetailsComponent
      },
      {
        path:'sidebar',
        component:SidebarComponent
      },
      {
        path:'scanner',
        component:ScannerComponent
      }
    ]
  },
  
  
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
