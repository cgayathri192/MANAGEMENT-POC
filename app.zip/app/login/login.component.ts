import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ManagementService } from '../management.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  Login: any;
  loginuser = '';

  constructor(private fb: FormBuilder, private ser: ManagementService,private router:Router) {

  }

  ngOnInit(): void {
    this.Login = this.fb.group({
      name: new FormControl('',
        [Validators.required, Validators.minLength(10), Validators.maxLength(15)]
      ),
      number: ['', [Validators.required]],
      password: ['', [Validators.required]],
      checkbox: '',
    })

  }
  get LoginErrors() {
    return this.Login.controls
  }
  login() {
    //  console.log(this.Login.value)
    //  console.log(this.LoginErrors.controls)
    this.ser.postLogin(this.Login.value).subscribe((x: any) => {
      console.log('................', x)
      const loginName = sessionStorage.getItem('name')
      const loginPassword = sessionStorage.getItem('password')
      sessionStorage.setItem('loggedIn', 'true')
      this.router.navigateByUrl('home')
      if (loginName == x.name &&  loginPassword == x.password) {
        this.router.navigateByUrl('main')
      } else {
        this.router.navigateByUrl('login')
      }

    })
    // Swal.fire({
    //   text:'Login successful',
    //   icon:'success'
    // })
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      didOpen: (toast:any) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    })
    
    Toast.fire({
      icon: 'success',
      title: 'Login successfull!'
    })
  }
}
