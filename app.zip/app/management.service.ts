import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ManagementService {

  constructor(private http:HttpClient) { }
  postRegister(data:any){
    return this.http.post('http://localhost:3000/register',data)
  }
  postLogin(data:any){
    return this.http.post('http://localhost:3000/login',data)
  }
  postDeposit(data:any){
    return this.http.post('http://localhost:3000/Deposit',data)
  }
  postwithdraw(data:any){
    return this.http.post('http://localhost:3000/withdraw',data)
  }
  postBalance(data:any){
   return this.http.post('http://localhost:3000/balance',data)
  }
  postTransfer(data:any){
    return this.http.post('http://localhost:3000/transfer',data)
  }
  postPin(data:any){
    return this.http.post('http://localhost:3000/pin',data)
  }
}
