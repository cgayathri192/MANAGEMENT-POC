import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.scss']
})
export class UserdetailsComponent implements OnInit {
  name = sessionStorage.getItem('name');
  password = sessionStorage.getItem('password');
  email = sessionStorage.getItem('email');
  account = sessionStorage.getItem('account');
  bank = sessionStorage.getItem('bank');
  code = sessionStorage.getItem('code');
  branch = sessionStorage.getItem('branch');
  type = sessionStorage.getItem('type');
  number = sessionStorage.getItem('number');
  confirm = sessionStorage.getItem('confirm')
  
ngOnInit() {
  
}


}
