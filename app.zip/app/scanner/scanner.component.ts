import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { NgxQrcodeElementTypes, NgxQrcodeErrorCorrectionLevels } from '@techiediaries/ngx-qrcode';



@Component({
  selector: 'app-scanner',
  templateUrl: './scanner.component.html',
  styleUrls: ['./scanner.component.scss']
})
export class ScannerComponent implements OnInit {
balanceForm:any;
elementType = NgxQrcodeElementTypes.URL;
correctionLevel = NgxQrcodeErrorCorrectionLevels.HIGH;
value = 'https://www.bankofbaroda.in/';
value1 = 'https://www.whatsapp.com/';
  constructor() { }

  ngOnInit(): void {
    this.balanceForm = new FormGroup({
      pin:new FormControl('')
    })
  }
  


}
